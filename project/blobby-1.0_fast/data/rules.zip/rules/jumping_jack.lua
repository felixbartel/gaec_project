__AUTHOR__ = "chameleon"
__TITLE__  = "Crazy Volley - Jumping Jack"
function HandleInput(player, left, right, up)
	return left, right, true
end
